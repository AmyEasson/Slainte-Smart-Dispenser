#!/usr/bin/env python3
"""
Run Sláinte Streamlit dashboard.
Start from repo root or dashboard directory:
  python dashboard/run_dashboard.py
  cd dashboard && python run_dashboard.py

If port 8501 is already in use, the script will try 8502, 8503, ... automatically.
Override with: set STREAMLIT_PORT=8502
"""
import os
import sys
import socket
import subprocess
import threading

# Ensure we run from the dashboard directory (where frontend/ lives)
script_dir = os.path.dirname(os.path.abspath(__file__))
os.chdir(script_dir)

# Suppress known Streamlit message from component manifest scan (NoneType in a dependency)
_STDERR_FILTER_PHRASE = "Failed to scan component manifests"


def _is_port_free(port: int) -> bool:
    """Return True if the port is available to bind."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        try:
            s.bind(("", port))
            return True
        except OSError:
            return False


def _find_available_port(start: int = 8501, max_tries: int = 10) -> int:
    """Return first free port in [start, start + max_tries)."""
    for i in range(max_tries):
        if _is_port_free(start + i):
            return start + i
    return start  # fallback; Streamlit will then report "port in use"


def _filtered_stderr_reader(pipe, dest):
    """Read lines from pipe and write to dest, skipping lines containing _STDERR_FILTER_PHRASE."""
    try:
        for line in iter(pipe.readline, ""):
            if _STDERR_FILTER_PHRASE not in line:
                dest.write(line)
                dest.flush()
    except (OSError, ValueError):
        pass
    finally:
        try:
            pipe.close()
        except OSError:
            pass


if __name__ == "__main__":
    if "STREAMLIT_PORT" in os.environ:
        try:
            port = int(os.environ["STREAMLIT_PORT"])
        except ValueError:
            port = _find_available_port()
    else:
        port = _find_available_port()
    print("=" * 60)
    print("Sláinte Dashboard")
    print("=" * 60)
    print(f"Starting Streamlit on http://localhost:{port}")
    print("Backend URL: set BACKEND_URL or default http://localhost:8080")
    if port != 8501:
        print("(Port 8501 was in use; using next available port.)")
    print("=" * 60)
    print("Press Ctrl+C to stop")
    print("=" * 60)
    # Run from frontend/ so that api_client, theme, etc. import without package prefix
    frontend_dir = os.path.join(script_dir, "frontend")
    os.chdir(frontend_dir)
    env = os.environ.copy()
    env.setdefault("STREAMLIT_LOGGER_LEVEL", "error")
    proc = subprocess.Popen(
        [
            sys.executable, "-m", "streamlit", "run",
            "1_Dashboard.py",
            f"--server.port={port}",
            "--server.address=localhost",
            "--browser.gatherUsageStats=false",
            "--logger.level=error",
        ],
        env=env,
        stderr=subprocess.PIPE,
        stdout=sys.stdout,
        text=True,
    )
    # Filter stderr to suppress "Failed to scan component manifests" (harmless dependency bug)
    t = threading.Thread(target=_filtered_stderr_reader, args=(proc.stderr, sys.stderr))
    t.daemon = True
    t.start()
    sys.exit(proc.wait())
