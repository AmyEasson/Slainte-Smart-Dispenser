"""
Plotly charts for Sláinte: time series, histogram, pie, intake timeline, adherence over time.
Light theme colors (WCAG).
"""
from typing import List

import pandas as pd
import plotly.graph_objects as go

from theme import (
    THEME_PAPER,
    THEME_PLOT,
    THEME_TEXT,
    THEME_PRIMARY,
    THEME_SUCCESS,
    THEME_MISSED,
    THEME_ERROR,
    THEME_SECONDARY,
    CHART_BG,
    CHART_GREEN_DARK,
    CHART_GREEN_LIGHT,
    CHART_GRADIENT,
)


def _records_to_dataframe(records: List[dict]) -> pd.DataFrame:
    """Convert intake records to DataFrame; add combined day+time for ordering."""
    if not records:
        return pd.DataFrame()
    df = pd.DataFrame(records)
    if df.empty:
        return df
    day_order = {"monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3, "friday": 4, "saturday": 5, "sunday": 6}
    df["_day_ord"] = df["day"].astype(str).str.lower().map(lambda d: day_order.get(d, 7))
    df["_time"] = df["time"].fillna("00:00").astype(str)
    df = df.sort_values(["_day_ord", "_time"])
    df["_label"] = df["day"].astype(str) + " " + df["_time"]
    return df


def _empty_fig(message: str = "No intake data available") -> go.Figure:
    fig = go.Figure()
    fig.add_annotation(text=message, xref="paper", yref="paper", x=0.5, y=0.5, showarrow=False, font=dict(size=14, color=THEME_TEXT))
    fig.update_layout(paper_bgcolor=CHART_BG, plot_bgcolor=CHART_BG, font=dict(color=THEME_TEXT), height=300)
    return fig


def _layout_light(fig: go.Figure, title: str, height: int = 400) -> None:
    fig.update_layout(
        title=title,
        title_font=dict(color=THEME_TEXT),
        paper_bgcolor=CHART_BG,
        plot_bgcolor=CHART_BG,
        font=dict(color=THEME_TEXT, size=12),
        xaxis=dict(
            gridcolor="#E0E0E0",
            tickfont=dict(color=THEME_TEXT),
            title_font=dict(color=THEME_TEXT),
        ),
        yaxis=dict(
            gridcolor="#E0E0E0",
            tickfont=dict(color=THEME_TEXT),
            title_font=dict(color=THEME_TEXT),
        ),
        height=height,
        showlegend=True,
        legend=dict(
            bgcolor=CHART_BG,
            bordercolor=CHART_GREEN_DARK,
            borderwidth=1,
            font=dict(color=THEME_TEXT),
        ),
    )


def create_time_series_line(records: List[dict], title: str = "Adherence over time (daily)") -> go.Figure:
    """Time series: X=date, Y=adherence % per day and/or taken vs missed counts."""
    if not records:
        return _empty_fig()
    df = pd.DataFrame(records)
    if "date" not in df.columns or "taken" not in df.columns:
        return _empty_fig()
    df["date"] = pd.to_datetime(df["date"], errors="coerce")
    df = df.dropna(subset=["date"])
    if df.empty:
        return _empty_fig()
    daily = df.groupby("date").agg(taken=("taken", "sum"), total=("taken", "count")).reset_index()
    daily["pct"] = (daily["taken"] / daily["total"] * 100).round(1)
    daily["missed"] = daily["total"] - daily["taken"]
    fig = go.Figure()
    fig.add_trace(
        go.Scatter(
            x=daily["date"],
            y=daily["pct"],
            mode="lines+markers",
            name="Adherence %",
            line=dict(color=CHART_GREEN_LIGHT, width=2),
            marker=dict(size=6),
        )
    )
    _layout_light(fig, title, height=380)
    fig.update_yaxes(title="Adherence %", range=[0, 105], title_font=dict(color=THEME_TEXT), tickfont=dict(color=THEME_TEXT))
    return fig


def create_taken_missed_histogram(records: List[dict], title: str = "Taken vs missed") -> go.Figure:
    """Histogram: bars for Taken and Missed counts."""
    if not records:
        return _empty_fig()
    df = pd.DataFrame(records)
    if "taken" not in df.columns:
        return _empty_fig()
    taken_count = int(df["taken"].sum())
    missed_count = int((~df["taken"].astype(bool)).sum())
    fig = go.Figure()
    fig.add_trace(
        go.Bar(x=["Taken"], y=[taken_count], name="Taken", marker_color=CHART_GREEN_LIGHT, text=[taken_count], textposition="outside")
    )
    fig.add_trace(
        go.Bar(x=["Missed"], y=[missed_count], name="Missed", marker_color=THEME_MISSED, text=[missed_count], textposition="outside")
    )
    _layout_light(fig, title, height=350)
    fig.update_yaxes(title="Count", title_font=dict(color=THEME_TEXT), tickfont=dict(color=THEME_TEXT))
    return fig


def create_vitamin_pie(records: List[dict], title: str = "Intake by vitamin type") -> go.Figure:
    """Pie chart: share of intake events per vitaminType. Distinct colors, labels outside."""
    if not records:
        return _empty_fig()
    df = pd.DataFrame(records)
    if "vitaminType" not in df.columns:
        return _empty_fig()
    counts = df["vitaminType"].value_counts().reset_index()
    counts.columns = ["vitaminType", "count"]
    colors = (CHART_GRADIENT + [CHART_GREEN_DARK, CHART_GREEN_LIGHT])[: len(counts)]
    fig = go.Figure(
        data=[
            go.Pie(
                labels=counts["vitaminType"],
                values=counts["count"],
                hole=0.4,
                marker=dict(colors=colors),
                textinfo="label+percent",
                textposition="outside",
                hovertemplate="%{label}<br>Count: %{value}<extra></extra>",
            )
        ]
    )
    _layout_light(fig, title, height=400)
    return fig


def create_intake_timeline(records: List[dict], title: str = "Intake timeline") -> go.Figure:
    """Bar: each intake event by day+time, color by taken (green) / missed (amber)."""
    df = _records_to_dataframe(records)
    if df.empty or "taken" not in df.columns:
        return _empty_fig()
    df["y"] = df["taken"].map(lambda t: 1 if t else 0)
    df["color"] = df["taken"].map(lambda t: CHART_GREEN_LIGHT if t else THEME_MISSED)
    labels = df["_label"].tolist()
    vitamin_labels = (df["vitaminType"].astype(str) + " (" + df["numberOfPills"].astype(str) + ")").tolist()
    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=labels,
            y=df["y"],
            name="Status",
            marker_color=df["color"],
            text=vitamin_labels,
            textposition="outside",
            hovertemplate="%{text}<br>%{x}<br>Status: %{y}<extra></extra>",
        )
    )
    _layout_light(fig, title)
    fig.update_yaxes(tickvals=[0, 1], ticktext=["Missed", "Taken"], title="", title_font=dict(color=THEME_TEXT), tickfont=dict(color=THEME_TEXT))
    fig.update_layout(showlegend=False)
    fig.update_xaxes(tickangle=-45, title_font=dict(color=THEME_TEXT), tickfont=dict(color=THEME_TEXT))
    return fig


def create_adherence_over_time(records: List[dict], title: str = "Adherence by day of week") -> go.Figure:
    """Bar: adherence % per weekday."""
    df = _records_to_dataframe(records)
    if df.empty or "taken" not in df.columns:
        return _empty_fig()
    agg = df.groupby("day").agg(taken=("taken", "sum"), total=("taken", "count")).reset_index()
    agg["pct"] = (agg["taken"] / agg["total"] * 100).round(1)
    day_order = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
    agg["day"] = pd.Categorical(agg["day"].astype(str).str.lower(), categories=day_order, ordered=True)
    agg = agg.sort_values("day")
    fig = go.Figure()
    fig.add_trace(
        go.Bar(
            x=agg["day"].astype(str).str.capitalize(),
            y=agg["pct"],
            name="Adherence %",
            marker_color=CHART_GREEN_LIGHT,
            text=agg["pct"].astype(str) + "%",
            textposition="outside",
        )
    )
    fig.add_hline(y=100, line_dash="dash", line_color=CHART_GREEN_LIGHT, annotation_text="100%")
    _layout_light(fig, title, height=350)
    fig.update_yaxes(title="Adherence %", range=[0, 105], title_font=dict(color=THEME_TEXT), tickfont=dict(color=THEME_TEXT))
    fig.update_layout(showlegend=False)
    return fig
