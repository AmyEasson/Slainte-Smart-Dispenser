"""
Sláinte Dashboard — light white-and-green Streamlit UI.
Consumes Spring Boot backend (live) or synthetic demo data. WCAG and Nielsen principles.
"""
import os
import sys
import time
from typing import List, Optional

import pandas as pd
import streamlit as st

# Ensure dashboard root is on path for services.data_science
_dashboard_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _dashboard_root not in sys.path:
    sys.path.insert(0, _dashboard_root)

from api_client import (
    BACKEND_URL,
    check_connection,
    get_intake,
    get_logs_csv,
    get_schedule,
)
from theme import apply_theme, PRIMARY_GREEN, SUCCESS_GREEN, WARNING_AMBER, ERROR_RED
from charts import (
    create_time_series_line,
    create_taken_missed_histogram,
    create_vitamin_pie,
    create_adherence_over_time,
    create_intake_timeline,
)
from components import (
    render_adherence_light,
    render_intake_feed,
    render_metric_box,
    render_status_indicator,
)

st.set_page_config(
    page_title="Sláinte Dashboard",
    page_icon="💊",
    layout="wide",
    initial_sidebar_state="expanded",
)

apply_theme()

if "auto_refresh" not in st.session_state:
    st.session_state.auto_refresh = False
if "refresh_interval" not in st.session_state:
    st.session_state.refresh_interval = 5
if "data_source" not in st.session_state:
    st.session_state.data_source = "Demo data"

# ----- Sidebar -----
with st.sidebar:
    st.title("Sláinte")
    st.markdown("---")
    st.subheader("Data source")
    data_source = st.radio(
        "Source",
        options=["Demo data", "Live backend"],
        index=0 if st.session_state.data_source == "Demo data" else 1,
        key="data_source_radio",
    )
    st.session_state.data_source = data_source
    st.markdown("---")
    st.subheader("Connection")
    api_online = check_connection()
    if data_source == "Live backend":
        render_status_indicator(api_online, BACKEND_URL)
    else:
        st.markdown('<p class="status-online">● Using demo data</p>', unsafe_allow_html=True)
    st.markdown("---")
    st.subheader("Auto refresh")
    auto_refresh = st.checkbox("Enable auto refresh", value=False)
    if auto_refresh:
        refresh_interval = st.slider("Interval (seconds)", 1, 60, 5)
        st.session_state.auto_refresh = True
        st.session_state.refresh_interval = refresh_interval
    else:
        st.session_state.auto_refresh = False
    st.markdown("---")
    if st.button("Refresh data", width="stretch"):
        st.rerun()

# ----- Fetch data (needed for sidebar CSV download) -----
if data_source == "Demo data":
    with st.spinner("Loading demo data..."):
        try:
            from services.data_science.synthetic_data import load_demo_data
            intake_records = load_demo_data()
        except Exception as e:
            intake_records = []
            st.error(f"Could not load demo data: {e}")
    schedule = None
    intake_message = None
else:
    if api_online:
        intake_records, intake_message = get_intake()
        schedule = get_schedule()
    else:
        intake_records = []
        intake_message = "Backend offline"
        schedule = None

# Sidebar: Download CSV (no raw table)
with st.sidebar:
    st.markdown("---")
    st.subheader("Export")
    if intake_records:
        if data_source == "Demo data":
            export_df = pd.DataFrame(intake_records)
            csv_str = export_df.to_csv(index=False)
            st.download_button(
                label="Download demo data (CSV)",
                data=csv_str,
                file_name="demo_intake.csv",
                mime="text/csv",
                width="stretch",
                key="sidebar_download_demo",
            )
            if st.button("Regenerate demo data", key="regenerate_demo", help="Regenerate synthetic data with seasonality and refresh"):
                from services.data_science.synthetic_data import load_demo_data
                load_demo_data(regenerate=True)
                st.rerun()
        else:
            csv_str, csv_error = get_logs_csv()
            if csv_error:
                st.caption(f"Export: {csv_error}")
            else:
                st.download_button(
                    label="Download logs (CSV)",
                    data=csv_str,
                    file_name="logs.csv",
                    mime="text/csv",
                    width="stretch",
                    key="sidebar_download_live",
                )
    else:
        st.caption("No data to export")

def compute_adherence_status(records: List[dict]) -> tuple[Optional[str], Optional[float]]:
    if not records:
        return "no_data", None
    taken = sum(1 for r in records if r.get("taken") is True)
    total = len(records)
    if total == 0:
        return "no_data", None
    pct = (taken / total) * 100
    if pct >= 80:
        return "on_track", pct
    if pct >= 50:
        return "missed", pct
    return "poor", pct

adherence_status, adherence_pct = compute_adherence_status(intake_records)
taken_count = sum(1 for r in intake_records if r.get("taken") is True)
missed_count = sum(1 for r in intake_records if r.get("taken") is False)
total_logged = len(intake_records)

# ----- Main layout -----
st.title("Sláinte Dashboard")
st.markdown("**Supplement intake monitoring**")
if data_source == "Demo data":
    st.info("Showing synthetic demo data. Switch to **Live backend** in the sidebar to use the Spring Boot API.")

# Top row: adherence light + metrics (same level)
st.subheader("Adherence")
col1, col2, col3, col4, col5 = st.columns([1.2, 1, 1, 1, 1])
with col1:
    render_adherence_light(adherence_status, adherence_pct)
with col2:
    render_metric_box("Taken", taken_count, "", SUCCESS_GREEN, stat_card=True)
with col3:
    render_metric_box("Missed", missed_count, "", WARNING_AMBER, stat_card=True)
with col4:
    render_metric_box("Total logged", total_logged, "", PRIMARY_GREEN, stat_card=True)
with col5:
    pct_str = f"{adherence_pct:.0f}%" if adherence_pct is not None else "—"
    render_metric_box("Adherence %", pct_str, "", PRIMARY_GREEN, stat_card=True)

st.markdown("---")

# Time series line
st.subheader("Adherence over time (daily)")
if intake_records:
    fig = create_time_series_line(intake_records, title="Daily adherence %")
    st.plotly_chart(fig, width="stretch")
else:
    st.info("No intake data available")

st.markdown("---")

# Histogram + Pie
col1, col2 = st.columns(2)
with col1:
    st.subheader("Taken vs missed")
    if intake_records:
        fig = create_taken_missed_histogram(intake_records)
        st.plotly_chart(fig, width="stretch")
    else:
        st.info("No intake data available")
with col2:
    st.subheader("Intake by vitamin type")
    if intake_records:
        fig = create_vitamin_pie(intake_records)
        st.plotly_chart(fig, width="stretch")
    else:
        st.info("No intake data available")

st.markdown("---")

# Intake timeline + Adherence by day
col1, col2 = st.columns(2)
with col1:
    st.subheader("Intake timeline")
    if intake_records:
        fig = create_intake_timeline(intake_records, title="Intake by day & time")
        st.plotly_chart(fig, width="stretch")
    else:
        st.info("No intake data available")
with col2:
    st.subheader("Adherence by day of week")
    if intake_records:
        fig = create_adherence_over_time(intake_records)
        st.plotly_chart(fig, width="stretch")
    else:
        st.info("No intake data available")

st.markdown("---")

# Recent intake feed
st.subheader("Recent intake")
render_intake_feed(intake_records, max_items=10)

st.markdown("---")

# Schedule (live only)
if schedule and schedule.get("vitamins"):
    with st.expander("Current schedule", expanded=False):
        for v in schedule["vitamins"]:
            st.markdown(f"**{v.get('vitaminType', 'N/A')}** — {v.get('numberOfPills', 0)} pill(s)")
            for ds in v.get("schedule") or []:
                times = ", ".join(ds.get("times") or [])
                st.caption(f"  {ds.get('day', '')}: {times}")

# Dosage recommendation (NLP + researched + usage)
with st.expander("Dosage recommendation", expanded=False):
    try:
        from services.data_science.synthetic_data import VITAMIN_TYPES
        from services.data_science.recommendation_service import recommend_amount, user_avg_pills_for_vitamin
    except ImportError:
        st.caption("Recommendation service not available.")
    else:
        st.markdown("Get a suggested amount (pills per dose) from label text and safe ranges. For supplements only; confirm with a healthcare provider.")
        rec_vitamin = st.selectbox("Vitamin / supplement type", options=VITAMIN_TYPES, key="rec_vitamin", label_visibility="visible")
        rec_description = st.text_area(
            "Supplement description or instructions (optional)",
            placeholder="e.g. Take 1-2 tablets daily with food, or paste full label text",
            key="rec_description",
            height=220,
            label_visibility="visible",
        )
        if st.button("Get suggestion", key="rec_btn"):
            user_avg = user_avg_pills_for_vitamin(intake_records, rec_vitamin) if intake_records else None
            result = recommend_amount(
                vitamin_type=rec_vitamin,
                description=rec_description.strip() or None,
                user_avg_pills_per_dose=user_avg,
            )
            amount = result["amount_to_consume"]
            source = result.get("source", "default")
            parsed_from_label = result.get("parsed_from_label")
            researched_used = result.get("researched_used", "")
            product_type_hint = result.get("product_type_hint")

            st.markdown("**From label:**")
            if parsed_from_label and parsed_from_label.get("summary"):
                st.markdown(parsed_from_label["summary"])
                ev = parsed_from_label.get("evidence") or ""
                if ev:
                    st.caption(f"*(from: \"{ev[:100]}{'…' if len(ev) > 100 else ''}\")*")
            else:
                st.markdown("No dosage found in description.")
            st.markdown("**Researched (for " + rec_vitamin + "):**")
            st.markdown(researched_used)
            if product_type_hint:
                st.info(product_type_hint)
            st.success(f"**Suggested:** {amount} pill(s) per dose. Source: {source}.")
        st.markdown("*For informational use only. Not medical advice.*")

if st.session_state.auto_refresh:
    time.sleep(st.session_state.refresh_interval)
    st.rerun()

st.markdown("---")
st.markdown(
    '<div style="text-align: center; color: #616161; font-size: 0.8rem;">Sláinte Dashboard | Light theme | Spring Boot Backend</div>',
    unsafe_allow_html=True,
)
