"""
Light white-and-green theme for Sláinte Dashboard.
WCAG 2.1 AA contrast and Nielsen usability (visibility, consistency, feedback).
"""
from typing import Optional

# WCAG AA: 4.5:1+ contrast on white
WHITE = "#FFFFFF"
BACKGROUND_LIGHT = "#F5F7F5"
TEXT_PRIMARY = "#1B1B1B"
PRIMARY_GREEN = "#2E7D32"
ACCENT_GREEN = "#4CAF50"
SECONDARY_GREEN = "#81C784"
SUCCESS_GREEN = "#2E7D32"
WARNING_AMBER = "#F57C00"
ERROR_RED = "#C62828"
BORDER_LIGHT = "#E0E0E0"

# Plotly / chart constants
THEME_PAPER = WHITE
THEME_PLOT = BACKGROUND_LIGHT
THEME_TEXT = TEXT_PRIMARY
THEME_PRIMARY = PRIMARY_GREEN
THEME_SUCCESS = ACCENT_GREEN
THEME_MISSED = WARNING_AMBER
THEME_ERROR = ERROR_RED
THEME_SECONDARY = SECONDARY_GREEN

# Chart green gradient (user-specified)
CHART_BG = "#f0f2f5"
CHART_GREEN_DARK = "#187804"
CHART_GREEN_LIGHT = "#2bfe19"
# Gradient list for multi-series charts (dark -> light)
CHART_GRADIENT = [CHART_GREEN_DARK, "#1e9a06", "#22b80a", "#26d610", CHART_GREEN_LIGHT]

LIGHT_THEME_CSS = """
<style>
    :root {
        --slainte-white: #FFFFFF;
        --slainte-bg: #F5F7F5;
        --slainte-text: #1B1B1B;
        --slainte-primary: #2E7D32;
        --slainte-accent: #4CAF50;
        --slainte-secondary: #81C784;
        --slainte-success: #2E7D32;
        --slainte-warning: #F57C00;
        --slainte-error: #C62828;
        --slainte-border: #E0E0E0;
        --slainte-shadow: 0 2px 8px rgba(0,0,0,0.06);
        --slainte-radius: 12px;
        --slainte-spacing: 1.5rem;
    }
    .stApp {
        background-color: var(--slainte-white);
        color: var(--slainte-text);
        font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', sans-serif;
        font-size: 16px;
        line-height: 1.5;
    }
    .stHeader { background-color: var(--slainte-bg); border-bottom: 2px solid var(--slainte-primary); }
    section[data-testid="stSidebar"] {
        background-color: var(--slainte-bg);
        border-right: 1px solid var(--slainte-secondary);
        color: var(--slainte-text);
    }
    section[data-testid="stSidebar"] p,
    section[data-testid="stSidebar"] label,
    section[data-testid="stSidebar"] span,
    section[data-testid="stSidebar"] .stMarkdown,
    section[data-testid="stSidebar"] h1,
    section[data-testid="stSidebar"] h2,
    section[data-testid="stSidebar"] h3 {
        color: var(--slainte-text);
    }
    .streamlit-expanderContent { color: var(--slainte-text); }
    [data-testid="stDataFrame"] { color: var(--slainte-text); }
    [data-testid="stMetricValue"] {
        color: var(--slainte-primary);
        font-size: 2rem;
        font-weight: bold;
    }
    [data-testid="stMetricLabel"] { color: var(--slainte-text); font-size: 0.95rem; }
    /* Ensure all widget labels are visible (WCAG contrast) */
    [data-testid="stWidgetLabel"] p,
    [data-testid="stWidgetLabel"] label,
    div[data-testid="stWidgetLabel"] {
        color: var(--slainte-text) !important;
        font-weight: 500;
    }
    /* Labels inside expanders (e.g. Dosage recommendation) must stay visible */
    .streamlit-expanderContent [data-testid="stWidgetLabel"] p,
    .streamlit-expanderContent [data-testid="stWidgetLabel"] label,
    .streamlit-expanderContent div[data-testid="stWidgetLabel"],
    .streamlit-expanderContent .stWidgetLabel {
        color: var(--slainte-text) !important;
        font-weight: 500;
    }
    .stButton > button {
        background-color: var(--slainte-primary);
        color: var(--slainte-white);
        border: 1px solid var(--slainte-primary);
        border-radius: 8px;
        font-weight: 600;
        transition: all 0.2s;
    }
    .stButton > button:hover {
        background-color: var(--slainte-accent);
        border-color: var(--slainte-accent);
    }
    .stSelectbox > div > div {
        background-color: var(--slainte-white);
        color: var(--slainte-text);
        border: 1px solid var(--slainte-border);
        border-radius: 8px;
    }
    .stTextInput > div > div > input {
        background-color: var(--slainte-white);
        color: var(--slainte-text);
        border: 1px solid var(--slainte-border);
        border-radius: 8px;
    }
    .streamlit-expanderHeader {
        background-color: var(--slainte-bg);
        color: var(--slainte-text);
        border: 1px solid var(--slainte-border);
        border-radius: var(--slainte-radius);
    }
    .stDataFrame { background-color: var(--slainte-white); }
    .metric-container, .metric-card {
        background-color: var(--slainte-white);
        border: 1px solid var(--slainte-border);
        border-radius: var(--slainte-radius);
        padding: 20px;
        margin: 10px 0;
        box-shadow: var(--slainte-shadow);
    }
    .metric-stat-card {
        min-height: 112px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: stretch;
        text-align: center;
    }
    /* Equal-height stat columns: stretch items inside Streamlit columns */
    [data-testid="stHorizontalBlock"] > [data-testid="column"] {
        display: flex;
        align-items: stretch;
    }
    [data-testid="stHorizontalBlock"] > [data-testid="column"] .metric-stat-card {
        flex: 1;
        width: 100%;
    }
    .metric-value {
        color: var(--slainte-primary);
        font-size: 2.5rem;
        font-weight: bold;
        margin: 0;
        line-height: 1.2;
    }
    .metric-label {
        color: var(--slainte-text);
        font-size: 0.95rem;
        margin-bottom: 6px;
        font-weight: 500;
    }
    .chart-card {
        background-color: var(--slainte-white);
        border: 1px solid var(--slainte-border);
        border-radius: var(--slainte-radius);
        padding: var(--slainte-spacing);
        margin-bottom: var(--slainte-spacing);
        box-shadow: var(--slainte-shadow);
    }
    .adherence-light {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        margin: 20px auto;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 0.9rem;
        color: var(--slainte-white);
        transition: all 0.3s;
        box-shadow: var(--slainte-shadow);
    }
    .adherence-ontrack { background-color: var(--slainte-success); }
    .adherence-missed { background-color: var(--slainte-warning); }
    .adherence-poor { background-color: var(--slainte-error); }
    .adherence-unknown { background-color: #757575; }
    .intake-item {
        background-color: var(--slainte-white);
        border-left: 4px solid var(--slainte-secondary);
        padding: 14px;
        margin: 8px 0;
        border-radius: 8px;
        box-shadow: var(--slainte-shadow);
    }
    .intake-item-taken { border-left-color: var(--slainte-success); }
    .intake-item-missed { border-left-color: var(--slainte-warning); }
    .status-online { color: var(--slainte-success); font-weight: bold; }
    .status-offline { color: var(--slainte-error); font-weight: bold; }
    h1 {
        color: var(--slainte-primary);
        border-bottom: 2px solid var(--slainte-primary);
        padding-bottom: 12px;
        margin-bottom: var(--slainte-spacing);
        font-weight: 700;
    }
    h2, h3 {
        color: var(--slainte-primary);
        margin-top: var(--slainte-spacing);
        margin-bottom: 0.75rem;
        font-weight: 600;
    }
    .block-container { padding-top: 2rem; padding-bottom: 2rem; }
    code {
        background-color: var(--slainte-bg);
        color: var(--slainte-primary);
        padding: 2px 8px;
        border-radius: 6px;
    }
</style>
"""


def apply_theme() -> None:
    """Apply light green theme to Streamlit app."""
    import streamlit as st
    st.markdown(LIGHT_THEME_CSS, unsafe_allow_html=True)


def get_adherence_color(status: Optional[str]) -> str:
    if status == "on_track":
        return SUCCESS_GREEN
    elif status == "missed":
        return WARNING_AMBER
    elif status == "poor":
        return ERROR_RED
    return "#757575"


def get_adherence_label(status: Optional[str]) -> str:
    labels = {"on_track": "ON TRACK", "missed": "MISSED", "poor": "POOR", "no_data": "NO DATA"}
    return labels.get(status, "NO DATA")
