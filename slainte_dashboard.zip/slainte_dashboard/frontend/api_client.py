"""
API client for Sláinte Spring Boot backend.
Calls GET /api/mobile/intake, getSchedule, logs/export.csv.
"""
import os
from typing import Any, List, Optional

import requests

# Base URL from env; default for local Spring Boot
BACKEND_URL = os.environ.get("BACKEND_URL", "http://localhost:8080").rstrip("/")
TIMEOUT = 10


def _url(path: str) -> str:
    return f"{BACKEND_URL}{path}"


def check_connection() -> bool:
    """Check if the Spring Boot backend is reachable (e.g. GET intake or health)."""
    try:
        r = requests.get(_url("/api/mobile/intake"), timeout=3)
        return r.status_code == 200
    except requests.RequestException:
        return False


def get_intake() -> tuple[List[dict], Optional[str]]:
    """
    GET /api/mobile/intake.
    Returns (list of intake records, message or None).
    Each record: { vitaminType, day, time, numberOfPills, taken }.
    """
    try:
        r = requests.get(_url("/api/mobile/intake"), timeout=TIMEOUT)
        r.raise_for_status()
        data = r.json()
        records = data.get("data") or []
        message = data.get("message")
        return records, message
    except requests.RequestException as e:
        return [], str(e)
    except (ValueError, KeyError):
        return [], "Invalid response from backend"


def get_schedule() -> Optional[dict]:
    """
    GET /api/mobile/getSchedule.
    Returns schedule payload: { vitamins: [ { vitaminType, numberOfPills, schedule: [ { day, times[] } ] } ] }.
    """
    try:
        r = requests.get(_url("/api/mobile/getSchedule"), timeout=TIMEOUT)
        r.raise_for_status()
        return r.json()
    except requests.RequestException:
        return None
    except ValueError:
        return None


def get_logs_csv() -> tuple[str, Optional[str]]:
    """
    GET /api/mobile/logs/export.csv.
    Returns (csv_string, None) on success or ("", error_message) on failure.
    """
    try:
        r = requests.get(_url("/api/mobile/logs/export.csv"), timeout=TIMEOUT)
        r.raise_for_status()
        return r.text, None
    except requests.RequestException as e:
        return "", str(e)
