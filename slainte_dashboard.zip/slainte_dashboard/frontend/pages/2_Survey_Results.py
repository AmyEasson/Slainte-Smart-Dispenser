"""
Survey Results — anonymised validation survey charts.
Loads CSV from dashboard/data/, displays aggregate charts only (no PII).
"""
import os
import sys

import pandas as pd
import plotly.graph_objects as go
import streamlit as st

# Dashboard root (folder containing frontend/ and data/)
_pages_dir = os.path.dirname(os.path.abspath(__file__))
_frontend_dir = os.path.dirname(_pages_dir)
_dashboard_root = os.path.dirname(_frontend_dir)
if _dashboard_root not in sys.path:
    sys.path.insert(0, _dashboard_root)

from theme import apply_theme
from theme import (
    THEME_TEXT,
    CHART_BG,
    CHART_GREEN_DARK,
    CHART_GREEN_LIGHT,
    CHART_GRADIENT,
)

SURVEY_CSV = os.path.join(
    _dashboard_root, "data", "Smart Supplement Dispenser – Validation Survey .csv"
)

# Short names for CSV columns we use (no PII)
COL_DAILY_INTAKE = "How many vitamins or supplements do you take daily?"
COL_FORGET = "How often do you forget to take your supplements?"
COL_TIME = "Approximately how much time do you spend managing your supplements each day?"
COL_TRACKING = "Do you currently use anything to track your supplement intake?"
COL_LIKELIHOOD = "After watching the video, how likely would you be to use this product?"
COL_RELIABILITY = "Reliability (never misses a dose)"
COL_REMINDERS = "Smart reminders"
COL_ANALYTICS = "Intake tracking & analytics"
COL_BARCODE = "Barcode scanning"
COL_WELLNESS = "Wellness correlation insights"

FEATURE_COLS = [COL_RELIABILITY, COL_REMINDERS, COL_ANALYTICS, COL_BARCODE, COL_WELLNESS]


def load_survey_df():
    """Load survey CSV; return DataFrame or None if missing."""
    if not os.path.isfile(SURVEY_CSV):
        return None
    try:
        df = pd.read_csv(SURVEY_CSV, encoding="utf-8")
        return df
    except Exception:
        try:
            df = pd.read_csv(SURVEY_CSV, encoding="utf-8-sig")
            return df
        except Exception:
            return None


def chart_layout(fig: go.Figure, title: str, height: int = 380) -> None:
    """Apply shared light-theme layout with green gradient background."""
    fig.update_layout(
        title=title,
        title_font=dict(color=THEME_TEXT),
        paper_bgcolor=CHART_BG,
        plot_bgcolor=CHART_BG,
        font=dict(color=THEME_TEXT, size=12),
        xaxis=dict(
            gridcolor="#E0E0E0",
            tickfont=dict(color=THEME_TEXT),
            title_font=dict(color=THEME_TEXT),
        ),
        yaxis=dict(
            gridcolor="#E0E0E0",
            tickfont=dict(color=THEME_TEXT),
            title_font=dict(color=THEME_TEXT),
        ),
        height=height,
        showlegend=True,
        legend=dict(
            bgcolor=CHART_BG,
            bordercolor=CHART_GREEN_DARK,
            borderwidth=1,
            font=dict(color=THEME_TEXT),
        ),
        margin=dict(t=60, b=50, l=50, r=30),
    )


def fig_daily_intake(df: pd.DataFrame) -> go.Figure:
    """Bar chart: count by daily supplement intake (0, 1-2, 3-5, 6-8, 9+)."""
    if COL_DAILY_INTAKE not in df.columns:
        return go.Figure()
    s = df[COL_DAILY_INTAKE].dropna().astype(str).str.strip()
    order = ["0", "1-2", "3-5", "6-8", "9+"]
    counts = s.value_counts().reindex(order).fillna(0).astype(int)
    fig = go.Figure(
        data=[
            go.Bar(
                x=counts.index,
                y=counts.values,
                name="Respondents",
                marker_color=CHART_GREEN_LIGHT,
                text=counts.values,
                textposition="outside",
            )
        ]
    )
    chart_layout(fig, "Daily supplement intake (how many do you take?)")
    fig.update_yaxes(title="Number of respondents")
    return fig


def fig_forgetfulness(df: pd.DataFrame) -> go.Figure:
    """Bar chart: how often respondents forget to take supplements."""
    if COL_FORGET not in df.columns:
        return go.Figure()
    s = df[COL_FORGET].dropna().astype(str).str.strip()
    counts = s.value_counts()
    # CSV labels -> short label and display order
    order_raw = ["Never", "Rarely (1–2x per month)", "Sometimes (1–2x per week)", "Often (3+ times per week)", "Almost daily"]
    labels_short = ["Never", "Rarely", "Sometimes", "Often", "Almost daily"]
    y_vals = [int(counts.get(raw, 0)) for raw in order_raw]
    fig = go.Figure(
        data=[
            go.Bar(
                x=labels_short,
                y=y_vals,
                name="Respondents",
                marker_color=CHART_GREEN_LIGHT,
                text=y_vals,
                textposition="outside",
            )
        ]
    )
    chart_layout(fig, "How often do you forget to take your supplements?")
    fig.update_yaxes(title="Number of respondents")
    return fig


def fig_time_spent(df: pd.DataFrame) -> go.Figure:
    """Bar chart: time spent managing supplements per day."""
    if COL_TIME not in df.columns:
        return go.Figure()
    s = df[COL_TIME].dropna().astype(str).str.strip()
    counts = s.value_counts()
    # Normalise common variants
    labels = list(counts.index)
    fig = go.Figure(
        data=[
            go.Bar(
                x=labels,
                y=counts.values,
                name="Respondents",
                marker_color=CHART_GREEN_DARK,
                text=counts.values,
                textposition="outside",
            )
        ]
    )
    chart_layout(fig, "Time spent managing supplements each day")
    fig.update_yaxes(title="Number of respondents")
    fig.update_xaxes(tickangle=-25)
    return fig


def fig_tracking_tools(df: pd.DataFrame) -> go.Figure:
    """Pie chart: what respondents use to track intake (No, Phone reminders, Pill organizer, App)."""
    if COL_TRACKING not in df.columns:
        return go.Figure()
    s = df[COL_TRACKING].dropna().astype(str).str.strip()
    counts = s.value_counts().reset_index()
    counts.columns = ["Tool", "Count"]
    colors = (CHART_GRADIENT + [CHART_GREEN_DARK, CHART_GREEN_LIGHT])[: len(counts)]
    fig = go.Figure(
        data=[
            go.Pie(
                labels=counts["Tool"],
                values=counts["Count"],
                hole=0.4,
                marker=dict(colors=colors),
                textinfo="label+percent",
                textposition="outside",
                hovertemplate="%{label}<br>Count: %{value}<extra></extra>",
            )
        ]
    )
    chart_layout(fig, "Do you use anything to track your supplement intake?")
    return fig


def fig_likelihood(df: pd.DataFrame) -> go.Figure:
    """Bar chart: likelihood to use product (1–5)."""
    if COL_LIKELIHOOD not in df.columns:
        return go.Figure()
    s = pd.to_numeric(df[COL_LIKELIHOOD], errors="coerce").dropna().astype(int)
    counts = s.value_counts().reindex([1, 2, 3, 4, 5]).fillna(0).astype(int)
    fig = go.Figure(
        data=[
            go.Bar(
                x=counts.index.astype(str),
                y=counts.values,
                name="Respondents",
                marker_color=CHART_GREEN_LIGHT,
                text=counts.values,
                textposition="outside",
            )
        ]
    )
    chart_layout(fig, "How likely would you be to use this product? (1 = not likely, 5 = very likely)")
    fig.update_yaxes(title="Number of respondents")
    fig.update_xaxes(title="Rating")
    return fig


def fig_feature_ratings(df: pd.DataFrame) -> go.Figure:
    """Horizontal bar: mean rating (1–5) for each feature."""
    short_names = {
        COL_RELIABILITY: "Reliability",
        COL_REMINDERS: "Smart reminders",
        COL_ANALYTICS: "Intake tracking & analytics",
        COL_BARCODE: "Barcode scanning",
        COL_WELLNESS: "Wellness correlation insights",
    }
    means = []
    labels = []
    for col in FEATURE_COLS:
        if col not in df.columns:
            continue
        vals = pd.to_numeric(df[col], errors="coerce").dropna()
        if len(vals) > 0:
            means.append(vals.mean())
            labels.append(short_names.get(col, col))
    if not means:
        return go.Figure()
    fig = go.Figure(
        data=[
            go.Bar(
                y=labels,
                x=means,
                orientation="h",
                name="Mean rating (1–5)",
                marker_color=CHART_GREEN_LIGHT,
                text=[f"{m:.1f}" for m in means],
                textposition="outside",
            )
        ]
    )
    chart_layout(fig, "Feature preference (mean rating 1–5)")
    fig.update_xaxes(title="Mean rating", range=[0, 5.5])
    fig.update_yaxes(title="")
    return fig


st.set_page_config(
    page_title="Survey Results — Sláinte",
    page_icon="📊",
    layout="wide",
    initial_sidebar_state="expanded",
)

apply_theme()

st.title("Survey Results")
st.markdown("**Validation survey — anonymised aggregate results**")
st.caption("Data used only for aggregate analysis. No individual responses or PII are shown.")

df = load_survey_df()
if df is None or df.empty:
    st.warning(f"Survey data file not found or empty. Expected: `data/Smart Supplement Dispenser – Validation Survey .csv`")
    st.stop()

n = len(df)
st.info(f"Anonymised survey results (n={n} respondents).")

# Row 1: Daily intake + Forgetfulness
c1, c2 = st.columns(2)
with c1:
    st.plotly_chart(fig_daily_intake(df), width="stretch")
with c2:
    st.plotly_chart(fig_forgetfulness(df), width="stretch")

# Row 2: Time spent + Tracking tools
c1, c2 = st.columns(2)
with c1:
    st.plotly_chart(fig_time_spent(df), width="stretch")
with c2:
    st.plotly_chart(fig_tracking_tools(df), width="stretch")

# Row 3: Likelihood to use
st.plotly_chart(fig_likelihood(df), width="stretch")

# Row 4: Feature ratings
st.plotly_chart(fig_feature_ratings(df), width="stretch")

st.markdown("---")
st.markdown(
    '<div style="text-align: center; color: #616161; font-size: 0.8rem;">Sláinte Dashboard | Survey Results (anonymised)</div>',
    unsafe_allow_html=True,
)
