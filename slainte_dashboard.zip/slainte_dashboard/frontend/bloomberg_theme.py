"""
Bloomberg Terminal Theme for Streamlit (Sláinte Dashboard)
Black and Orange color scheme
"""
from typing import Optional

BBG_THEME = """
<style>
    /* Bloomberg Terminal Theme */
    :root {
        --bbg-black: #0d1117;
        --bbg-dark-gray: #161b22;
        --bbg-gray: #21262d;
        --bbg-orange: #FF6600;
        --bbg-orange-light: #FF8533;
        --bbg-orange-dark: #CC5200;
        --bbg-green: #00FF00;
        --bbg-red: #FF0000;
        --bbg-yellow: #FFFF00;
        --bbg-white: #FFFFFF;
        --bbg-text: #CCCCCC;
        --bbg-text-dim: #888888;
    }
    
    /* Main App Background */
    .stApp {
        background-color: var(--bbg-black);
        color: var(--bbg-text);
        font-family: 'Courier New', 'Consolas', monospace;
    }
    
    /* Header */
    .stHeader {
        background-color: var(--bbg-dark-gray);
        border-bottom: 2px solid var(--bbg-orange);
    }
    
    /* Sidebar */
    section[data-testid="stSidebar"] {
        background-color: var(--bbg-dark-gray);
        border-right: 1px solid var(--bbg-orange);
    }
    
    /* Metrics/Value Boxes */
    [data-testid="stMetricValue"] {
        color: var(--bbg-orange);
        font-size: 2rem;
        font-weight: bold;
        font-family: 'Courier New', monospace;
    }
    
    [data-testid="stMetricLabel"] {
        color: var(--bbg-text);
        font-size: 0.9rem;
        font-family: 'Courier New', monospace;
    }
    
    /* Buttons */
    .stButton > button {
        background-color: var(--bbg-orange);
        color: var(--bbg-black);
        border: 1px solid var(--bbg-orange);
        border-radius: 4px;
        font-weight: bold;
        font-family: 'Courier New', monospace;
        transition: all 0.3s;
    }
    
    .stButton > button:hover {
        background-color: var(--bbg-orange-light);
        border-color: var(--bbg-orange-light);
    }
    
    /* Selectbox/Dropdown */
    .stSelectbox > div > div {
        background-color: var(--bbg-gray);
        color: var(--bbg-text);
        border: 1px solid var(--bbg-orange);
    }
    
    /* Text Input */
    .stTextInput > div > div > input {
        background-color: var(--bbg-gray);
        color: var(--bbg-text);
        border: 1px solid var(--bbg-orange);
    }
    
    /* Slider */
    .stSlider > div > div {
        background-color: var(--bbg-gray);
    }
    
    /* Expander */
    .streamlit-expanderHeader {
        background-color: var(--bbg-dark-gray);
        color: var(--bbg-text);
        border: 1px solid var(--bbg-orange);
    }
    
    /* Dataframe */
    .stDataFrame {
        background-color: var(--bbg-dark-gray);
    }
    
    /* Adherence Light (reused from regime light) */
    .adherence-light {
        width: 120px;
        height: 120px;
        border-radius: 50%;
        margin: 20px auto;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: bold;
        font-size: 0.9rem;
        color: var(--bbg-black);
        box-shadow: 0 0 30px currentColor;
        transition: all 0.3s;
    }
    
    .adherence-ontrack {
        background-color: var(--bbg-green);
        box-shadow: 0 0 30px var(--bbg-green);
    }
    
    .adherence-missed {
        background-color: var(--bbg-yellow);
        box-shadow: 0 0 30px var(--bbg-yellow);
    }
    
    .adherence-poor {
        background-color: var(--bbg-red);
        box-shadow: 0 0 30px var(--bbg-red);
        animation: pulse 1s infinite;
    }
    
    .adherence-unknown {
        background-color: #888888;
        box-shadow: 0 0 30px #888888;
    }
    
    @keyframes pulse {
        0%, 100% { opacity: 1; }
        50% { opacity: 0.7; }
    }
    
    /* Metric Container */
    .metric-container {
        background-color: var(--bbg-dark-gray);
        border: 2px solid var(--bbg-orange);
        border-radius: 6px;
        padding: 15px;
        margin: 10px 0;
    }
    
    .metric-value {
        color: var(--bbg-orange);
        font-size: 2.5rem;
        font-weight: bold;
        font-family: 'Courier New', monospace;
        margin: 0;
    }
    
    .metric-label {
        color: var(--bbg-text);
        font-size: 1rem;
        font-family: 'Courier New', monospace;
        margin-bottom: 5px;
    }
    
    /* Intake Feed Item (reused from news item) */
    .intake-item {
        background-color: var(--bbg-dark-gray);
        border-left: 4px solid var(--bbg-orange);
        padding: 10px;
        margin: 5px 0;
        border-radius: 4px;
    }
    
    .intake-item-taken {
        border-left-color: var(--bbg-green);
    }
    
    .intake-item-missed {
        border-left-color: var(--bbg-red);
    }
    
    /* Status Badge */
    .status-online {
        color: var(--bbg-green);
        font-weight: bold;
    }
    
    .status-offline {
        color: var(--bbg-red);
        font-weight: bold;
    }
    
    /* Title Styling */
    h1 {
        color: var(--bbg-orange);
        font-family: 'Courier New', monospace;
        border-bottom: 2px solid var(--bbg-orange);
        padding-bottom: 10px;
    }
    
    h2, h3 {
        color: var(--bbg-orange-light);
        font-family: 'Courier New', monospace;
    }
    
    /* Code blocks */
    code {
        background-color: var(--bbg-dark-gray);
        color: var(--bbg-orange);
        padding: 2px 6px;
        border-radius: 3px;
    }
</style>
"""

# Theme colors for Plotly
BBG_BLACK = "#0d1117"
BBG_DARK_GRAY = "#161b22"
BBG_GRAY = "#21262d"
BBG_ORANGE = "#FF6600"
BBG_ORANGE_LIGHT = "#FF8533"
BBG_GREEN = "#00FF00"
BBG_RED = "#FF0000"
BBG_YELLOW = "#FFFF00"
BBG_WHITE = "#FFFFFF"
BBG_TEXT = "#CCCCCC"


def apply_theme():
    """Apply Bloomberg theme to Streamlit app."""
    import streamlit as st
    st.markdown(BBG_THEME, unsafe_allow_html=True)


def get_adherence_color(status: Optional[str]) -> str:
    """Get color for adherence status."""
    if status == "on_track":
        return BBG_GREEN
    elif status == "missed":
        return BBG_YELLOW
    elif status == "poor":
        return BBG_RED
    else:
        return "#888888"


def get_adherence_label(status: Optional[str]) -> str:
    """Get label for adherence status."""
    labels = {
        "on_track": "ON TRACK",
        "missed": "MISSED",
        "poor": "POOR",
        "no_data": "NO DATA",
    }
    return labels.get(status, "NO DATA")
