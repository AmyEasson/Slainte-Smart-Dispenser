"""
Sláinte dashboard components: adherence light, metric boxes, intake feed.
Light white-and-green theme (WCAG/Nielsen).
"""
from typing import Any, List, Optional

import streamlit as st

from theme import get_adherence_color, get_adherence_label, PRIMARY_GREEN


def render_adherence_light(status: Optional[str], adherence_pct: Optional[float] = None):
    """Render adherence traffic light: on_track, missed, poor, no_data (inside card)."""
    if status is None or status == "no_data":
        st.markdown("""
        <div class="metric-card">
            <div class="adherence-light adherence-unknown">
                <div style="text-align: center;">
                    <div style="font-size: 0.8rem; margin-bottom: 5px;">NO DATA</div>
                </div>
            </div>
        </div>
        """, unsafe_allow_html=True)
        return

    color = get_adherence_color(status)
    label = get_adherence_label(status)
    status_class = status if status in ("on_track", "missed", "poor") else "unknown"
    pct_html = f'<div style="font-size: 0.7rem;">{adherence_pct:.0f}%</div>' if adherence_pct is not None else ""

    st.markdown(f"""
    <div class="metric-card">
        <div class="adherence-light adherence-{status_class}" style="background-color: {color};">
            <div style="text-align: center;">
                <div style="font-size: 0.8rem; margin-bottom: 5px;">{label}</div>
                {pct_html}
            </div>
        </div>
    </div>
    """, unsafe_allow_html=True)


def render_metric_box(label: str, value: Any, unit: str = "", color: Optional[str] = None, stat_card: bool = False):
    """Render a metric box (light theme; default primary green). Use stat_card=True for even-height key stats."""
    if color is None:
        color = PRIMARY_GREEN
    if isinstance(value, float):
        value_str = f"{value:.2f}"
    elif isinstance(value, int):
        value_str = f"{value:,}"
    else:
        value_str = str(value)
    extra_class = " metric-stat-card" if stat_card else ""
    st.markdown(f"""
    <div class="metric-container metric-card{extra_class}">
        <div class="metric-label">{label}</div>
        <div class="metric-value" style="color: {color};">{value_str}{unit}</div>
    </div>
    """, unsafe_allow_html=True)


def render_intake_feed(records: List[dict], max_items: int = 10):
    """Render intake feed: last N events with taken/missed styling."""
    if not records:
        st.info("No intake data available")
        return

    for row in records[:max_items]:
        vitamin_type = row.get("vitaminType", "N/A")
        day = row.get("day", "N/A")
        time_val = row.get("time", "N/A")
        pills = row.get("numberOfPills", 0)
        taken = row.get("taken")
        if taken is True:
            item_class = "intake-item intake-item-taken"
            status_label = "TAKEN"
        elif taken is False:
            item_class = "intake-item intake-item-missed"
            status_label = "MISSED"
        else:
            item_class = "intake-item"
            status_label = "—"

        st.markdown(f"""
        <div class="{item_class}">
            <div style="font-weight: bold; color: #1B1B1B; margin-bottom: 5px;">
                {vitamin_type} — {pills} pill(s)
            </div>
            <div style="font-size: 0.9rem; color: #424242;">
                {day} {time_val} | {status_label}
            </div>
        </div>
        """, unsafe_allow_html=True)


def render_status_indicator(online: bool, backend_url: str = "http://localhost:8080"):
    """Render API connection status indicator."""
    if online:
        st.markdown('<p class="status-online">● Backend connected</p>', unsafe_allow_html=True)
    else:
        st.markdown('<p class="status-offline">● Backend offline</p>', unsafe_allow_html=True)
        st.error(f"Cannot connect to Spring Boot. Ensure backend is running at {backend_url}")
