# Ethical ML Strategy for Sláinte

This document outlines ML opportunities for the Sláinte supplement adherence system that keep users engaged while respecting privacy and ethics. All processing stays within the system; no sharing of individual intake data with third parties or other users.

## Guardrails

- **No leakage:** No raw intake rows or PII in external APIs, training data, or prompts unless the user opts in and data is anonymized or aggregated.
- **Transparency:** Explain in UI or docs what data is used for suggestions and that it stays in the system.
- **Consent:** For new ML features, allow opt-out or opt-in as appropriate.
- **Minimal data:** Prefer aggregates (counts, percentages, trends) over raw logs in any ML or chatbot pipeline.

---

## 1. Recommendation and personalization

Use only the **user’s own** history; no cross-user data.

- **Optimal time / schedule suggestions:** Use adherence by weekday and time to suggest “best times” or “best days” for a supplement. Use simple rules or small classifiers on **aggregates** (e.g. adherence % by day/time), not raw rows in external systems.
- **Supplement variety / balance:** From the same user’s intake, suggest “you often take X; consider adding Y” or “spread intake across the day” using only that user’s counts by vitamin type and time.
- **Data scope:** Train or infer only on data the backend already has for that user; no export of raw logs to external ML services unless explicitly consented and anonymized.

---

## 2. Chatbot / conversational layer

- **Purpose:** Answer questions like “How did I do this week?”, “When do I usually take Vitamin D?”, “Tips for remembering?” using **only that user’s aggregated stats** (adherence %, counts by vitamin, by day). No raw intake rows in prompts; no other users’ data.
- **Implementation:** FAQ and template answers driven by precomputed metrics (e.g. “This week you took 85% of scheduled doses”), or a small LLM with strict input rules: only anonymized, aggregated inputs; no PII or raw logs in the prompt.
- **Ethics:** Clear disclaimer that the bot is for support and not medical advice; logs and prompts not used to train public models or shared.

---

## 3. Engagement and retention (ethical nudge design)

- **Streaks and milestones:** Use adherence over time to show “7-day streak” or “Best week” without storing or exposing raw intake; only derived counters (e.g. current_streak, best_streak) per user.
- **Reminders and nudges:** Use simple ML or rules (e.g. “often missed on Fridays”) to suggest “Consider a reminder on Friday afternoon” or “You do best with morning doses.” All based on that user’s aggregates only.
- **Gamification:** Badges or levels from adherence bands (e.g. >90% = “On track”) without leaderboards or cross-user comparison to avoid pressure and privacy issues.

---

## 4. Dosage recommendation (NLP + researched + usage)

Combines a **custom NLP pipeline** (regex + rule-based NER) on supplement description text, **researched safe ranges** per vitamin type, and the **user’s usage aggregates** to suggest a safe **amount to consume** (pills per dose).

- **NLP pipeline:** Extracts min/max dosage from free text (e.g. “Take 1–2 tablets daily”, “Do not exceed 3 per day”). Implemented in `services/data_science/nlp_dosage.py` with regex patterns; no external APIs. Very large parsed values are capped; if nothing is parsed, downstream uses default bounds.
- **Researched recommendations:** Internal JSON (`researched_recommendations.json`) with safe min/max/typical per supplement type; sourced from trusted guidance (e.g. NHS, FDA). Reference data only; no PII.
- **User usage:** Only **aggregates** (e.g. average pills per dose for that vitamin from intake records) are used to nudge the suggestion toward the user’s current behavior within the safe range. No raw intake rows sent outside the system.
- **Hardcoded bounds:** When no constraint is found or the value is extremely large, the system uses configurable default bounds (e.g. `0 <= amount_to_consume <= 4`). This ensures we never suggest an unreasonably high number.
- **Disclaimer:** All recommendations are for supplements only and for informational use; users should confirm with a healthcare provider. This is shown in the UI wherever the suggested amount is displayed.

---

## 5. Implementation notes

- Implement incrementally; start with rule-based or aggregate-only features.
- Document in the UI what data is used for each feature.
- Keep user data on your backend; do not send raw intake to third-party ML APIs without consent and clear disclosure.
