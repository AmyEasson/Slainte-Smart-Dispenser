# Data science service: synthetic intake data, dosage NLP, recommendation
from .synthetic_data import generate_synthetic_intake, load_demo_data, save_to_data_dir
from .recommendation_service import (
    recommend_amount,
    get_researched_range,
    user_avg_pills_for_vitamin,
    DEFAULT_MIN_PILLS,
    DEFAULT_MAX_PILLS,
)

__all__ = [
    "generate_synthetic_intake",
    "load_demo_data",
    "save_to_data_dir",
    "recommend_amount",
    "get_researched_range",
    "user_avg_pills_for_vitamin",
    "DEFAULT_MIN_PILLS",
    "DEFAULT_MAX_PILLS",
]
