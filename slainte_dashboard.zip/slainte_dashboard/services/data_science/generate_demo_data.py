#!/usr/bin/env python3
"""Generate and save synthetic intake CSV to dashboard/data/. Run from dashboard/: python -m services.data_science.generate_demo_data"""
from .synthetic_data import generate_synthetic_intake, save_to_data_dir

if __name__ == "__main__":
    df = generate_synthetic_intake(weeks=6, seed=42)
    path = save_to_data_dir(df)
    print(f"Saved {len(df)} rows to {path}")
