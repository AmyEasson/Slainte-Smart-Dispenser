"""
Synthetic seasonal intake data for Sláinte dashboard demo.
Schema: vitaminType, day, time, numberOfPills, taken, date (for time series).
Uses seasonality (weekly and weekend effects) and small randomness for human-like diversity.
"""
import os
import random
from datetime import date, timedelta
from typing import List

import pandas as pd

VITAMIN_TYPES = ["Vitamin D", "Multivitamin", "Omega-3", "Iron", "Vitamin C", "Magnesium"]
DAYS = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]
# Base times; time noise adds quarter-hour variety for realism
TIMES_AM = ["07:00", "07:15", "07:30", "08:00", "08:30", "09:00"]
TIMES_PM = ["18:00", "18:30", "19:00", "19:30", "20:00"]

# Dashboard root: dashboard/ (parent of services/)
_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_DASHBOARD_ROOT = os.path.dirname(os.path.dirname(_THIS_DIR))
DATA_DIR = os.path.join(_DASHBOARD_ROOT, "data")
DEFAULT_FILENAME = "synthetic_intake.csv"


def _seasonal_adherence_factor(week_index: int, total_weeks: int) -> float:
    """
    Human-like seasonality: slower start (routine building), best in middle, slight dip then stable.
    Returns a multiplier around 1.0 (e.g. 0.72–1.0).
    """
    t = week_index / max(1, total_weeks - 1)  # 0 .. 1 over the period
    # Start a bit lower, peak mid-period, gentle end
    if t < 0.2:
        base = 0.72 + 0.10 * (t / 0.2)  # 0.72 -> 0.82
    elif t < 0.6:
        base = 0.82 + 0.10 * ((t - 0.2) / 0.4)  # 0.82 -> 0.92
    else:
        base = 0.92 - 0.03 * ((t - 0.6) / 0.4)  # 0.92 -> 0.89
    return base


def _n_events_human() -> int:
    """Most days 2–3 events; occasionally 1 or 4 for variety."""
    r = random.random()
    if r < 0.12:
        return 1
    if r < 0.55:
        return 2
    if r < 0.88:
        return 3
    return 4


def _pills_human() -> int:
    """Most often 1–2 pills; sometimes 3."""
    r = random.random()
    if r < 0.50:
        return 1
    if r < 0.85:
        return 2
    return 3


def _time_slot_human() -> str:
    """Slight bias to morning (e.g. 55% AM)."""
    if random.random() < 0.55:
        return random.choice(TIMES_AM)
    return random.choice(TIMES_PM)


def generate_synthetic_intake(weeks: int = 6, seed: int = 42) -> pd.DataFrame:
    """
    Generate seasonal, human-like intake data:
    - Seasonality: lower adherence in first weeks (routine building), best in middle, slight variation by week.
    - Weekend effect: slightly worse adherence on Saturday/Sunday.
    - Random diversification: variable events per day (2–3 typical), pill count (1–2 typical), time preference (AM bias).
    - Occasional bad day: small chance per day that adherence drops for that day only.
    Returns DataFrame with columns: date, vitaminType, day, time, numberOfPills, taken.
    """
    random.seed(seed)
    start = date.today() - timedelta(weeks=weeks)
    rows = []
    day_names = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]

    for i in range(weeks * 7):
        d = start + timedelta(days=i)
        day_name = day_names[d.weekday()]
        week_index = i // 7

        # Seasonality: weekly factor (routine building -> best -> stable)
        season = _seasonal_adherence_factor(week_index, weeks)
        # Weekend: slightly lower base
        is_weekend = d.weekday() >= 5
        weekend_dip = -0.06 if is_weekend else 0.0
        # Small per-day randomness (noise)
        day_noise = random.uniform(-0.04, 0.04)
        # Occasional "bad day" (e.g. forgot more often)
        bad_day = random.random() < 0.04
        bad_day_dip = -0.15 if bad_day else 0.0

        base_p = season + weekend_dip + day_noise + bad_day_dip
        p_taken = max(0.50, min(0.96, base_p))

        n_events = _n_events_human()
        # Per-week "habit": same 2–3 vitamins more likely (realism)
        week_habit = random.sample(VITAMIN_TYPES, k=min(3, len(VITAMIN_TYPES))) if random.random() < 0.6 else None
        for _ in range(n_events):
            vitamin = random.choice(week_habit) if week_habit and random.random() < 0.7 else random.choice(VITAMIN_TYPES)
            time_slot = _time_slot_human()
            pills = _pills_human()
            # Tiny per-event randomness so same day isn't all-or-nothing
            event_p = p_taken + random.uniform(-0.03, 0.03)
            event_p = max(0.0, min(1.0, event_p))
            taken = random.random() < event_p
            rows.append({
                "date": d.isoformat(),
                "vitaminType": vitamin,
                "day": day_name,
                "time": time_slot,
                "numberOfPills": pills,
                "taken": taken,
            })
    return pd.DataFrame(rows)


def save_to_data_dir(df: pd.DataFrame, filename: str = DEFAULT_FILENAME) -> str:
    """Write DataFrame to dashboard/data/; create dir if needed. Returns path."""
    os.makedirs(DATA_DIR, exist_ok=True)
    path = os.path.join(DATA_DIR, filename)
    df.to_csv(path, index=False)
    return path


def load_demo_data(regenerate: bool = False) -> List[dict]:
    """
    Load intake records from data/synthetic_intake.csv.
    If file is missing (or regenerate=True), generate with seasonality and save then return.
    Returns list of dicts with vitaminType, day, time, numberOfPills, taken, date.
    To get fresh human-like data, delete data/synthetic_intake.csv or pass regenerate=True.
    """
    path = os.path.join(DATA_DIR, DEFAULT_FILENAME)
    if regenerate or not os.path.isfile(path):
        df = generate_synthetic_intake(weeks=6, seed=42)
        save_to_data_dir(df, DEFAULT_FILENAME)
    else:
        df = pd.read_csv(path)
    # Ensure boolean for taken
    if "taken" in df.columns:
        df["taken"] = df["taken"].map(lambda x: x is True or str(x).lower() == "true" if isinstance(x, str) else bool(x))
    if "date" not in df.columns and len(df) > 0:
        df["date"] = date.today().isoformat()
    return df.to_dict("records")
