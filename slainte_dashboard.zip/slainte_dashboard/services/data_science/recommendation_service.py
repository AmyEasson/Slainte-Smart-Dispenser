"""
Recommendation service: combines NLP-parsed dosage from description,
researched safe ranges per vitamin type, and optional user usage aggregates
to suggest a safe amount_to_consume (pills per dose) with hardcoded bounds.
Returns parsed_from_label and researched_used for UI transparency.
"""
import json
import os
import re
from typing import Any, Optional

from .nlp_dosage import parse_dosage_from_text

# Hardcoded bounds when no or extreme constraint found (plan: 0 <= amount <= 4)
DEFAULT_MIN_PILLS = 0
DEFAULT_MAX_PILLS = 4

_THIS_DIR = os.path.dirname(os.path.abspath(__file__))
_RECOMMENDATIONS_PATH = os.path.join(_THIS_DIR, "researched_recommendations.json")

_researched_cache: Optional[dict[str, dict]] = None

# Phrases that suggest the description is for a multivitamin (use Multivitamin range for cap when selected type is single vitamin)
MULTIVITAMIN_PHRASES = re.compile(
    r"multivitamin|multi-vitamin|multi vitamin|complete multivitamin|multi-purpose tablet",
    re.I,
)


def _load_researched() -> dict[str, dict]:
    """Load researched_recommendations.json (cached). Keys normalized to title case."""
    global _researched_cache
    if _researched_cache is not None:
        return _researched_cache
    if not os.path.isfile(_RECOMMENDATIONS_PATH):
        _researched_cache = {}
        return _researched_cache
    with open(_RECOMMENDATIONS_PATH, encoding="utf-8") as f:
        raw = json.load(f)
    # Strip keys that are metadata (e.g. _source)
    out = {}
    for k, v in raw.items():
        if k.startswith("_"):
            continue
        name = k.strip()
        if name:
            out[name] = {kk: vv for kk, vv in v.items() if not kk.startswith("_")}
    _researched_cache = out
    return _researched_cache


def get_researched_range(vitamin_type: str) -> Optional[dict[str, Any]]:
    """
    Look up researched min/max/typical for a vitamin type.
    Returns dict with min_pills_per_day, max_pills_per_day, typical_per_dose or None.
    """
    if not vitamin_type or not vitamin_type.strip():
        return None
    researched = _load_researched()
    # Normalize: title case, strip
    key = vitamin_type.strip().title()
    return researched.get(key)


def _researched_summary(researched: Optional[dict], vitamin_type: str) -> str:
    """One-line summary of researched range for UI."""
    if not researched:
        return "No researched range for this type."
    typical = researched.get("typical_per_dose")
    max_day = researched.get("max_pills_per_day")
    parts = []
    if typical is not None:
        parts.append(f"typical {typical} per dose")
    if max_day is not None:
        parts.append(f"max {max_day} per day")
    return "; ".join(parts) if parts else "Researched range available."


def _parsed_summary(parsed: dict) -> str:
    """Short summary of parsed label for UI."""
    min_d = parsed.get("min_per_dose")
    max_d = parsed.get("max_per_dose")
    max_day = parsed.get("max_per_day")
    parts = []
    if min_d is not None and max_d is not None:
        if min_d == max_d:
            parts.append(f"{max_d} per dose")
        else:
            parts.append(f"{min_d}–{max_d} per dose")
    if max_day is not None:
        parts.append(f"{max_day} per day")
    return "; ".join(parts) if parts else "Parsed from label."


def recommend_amount(
    vitamin_type: str,
    description: Optional[str] = None,
    user_avg_pills_per_dose: Optional[float] = None,
) -> dict[str, Any]:
    """
    Recommend amount_to_consume (pills per dose) using:
    1) Parsed constraints from description (NLP) — preferred when present
    2) Researched range for vitamin_type (or Multivitamin if description suggests multivitamin and type is single)
    3) Optional nudge toward user_avg_pills_per_dose within safe range

    Returns dict: amount_to_consume, source, parsed_from_label, researched_used, product_type_hint.
    Always 0 <= amount_to_consume <= DEFAULT_MAX_PILLS (4).
    """
    parsed = None
    if description and description.strip():
        parsed = parse_dosage_from_text(description)

    # Researched range: use selected type, or Multivitamin if description looks like multivitamin and we have a single-vitamin selected
    researched = get_researched_range(vitamin_type) if vitamin_type else None
    product_type_hint = None
    if description and MULTIVITAMIN_PHRASES.search(description) and researched:
        multi = get_researched_range("Multivitamin")
        if multi and vitamin_type and vitamin_type.strip().title() != "Multivitamin":
            # Use the stricter of the two for max (cap by both)
            researched = {
                "min_pills_per_day": researched.get("min_pills_per_day"),
                "max_pills_per_day": min(
                    int(researched.get("max_pills_per_day") or DEFAULT_MAX_PILLS),
                    int(multi.get("max_pills_per_day") or DEFAULT_MAX_PILLS),
                ),
                "typical_per_dose": researched.get("typical_per_dose"),
            }
            product_type_hint = "Description looks like a multivitamin; safe range applied from Multivitamin guidance where relevant."
    researched_used = _researched_summary(researched, vitamin_type or "")

    # Build parsed_from_label for UI (None or dict with summary + evidence)
    parsed_from_label = None
    if parsed:
        parsed_from_label = {
            "min_per_dose": parsed.get("min_per_dose"),
            "max_per_dose": parsed.get("max_per_dose"),
            "max_per_day": parsed.get("max_per_day"),
            "evidence": parsed.get("evidence"),
            "summary": _parsed_summary(parsed),
        }

    # Effective range: per dose; prefer parsed, cap by researched
    min_eff = DEFAULT_MIN_PILLS
    max_eff = DEFAULT_MAX_PILLS

    if parsed:
        p_min = parsed.get("min_per_dose", DEFAULT_MIN_PILLS)
        p_max = parsed.get("max_per_dose", DEFAULT_MAX_PILLS)
        p_max = min(p_max, DEFAULT_MAX_PILLS)
        min_eff = max(min_eff, p_min)
        max_eff = min(max_eff, p_max)
        if min_eff > max_eff:
            max_eff = min_eff

    if researched:
        r_max_day = researched.get("max_pills_per_day")
        r_typical = researched.get("typical_per_dose")
        if r_max_day is not None:
            r_max_day = min(int(r_max_day), DEFAULT_MAX_PILLS)
            max_eff = min(max_eff, r_max_day)
        if min_eff > max_eff:
            max_eff = min_eff
        if parsed is None and r_typical is not None:
            t = min(max(0, int(r_typical)), DEFAULT_MAX_PILLS)
            if t <= max_eff and t >= min_eff:
                amount = t
                if user_avg_pills_per_dose is not None:
                    u = int(round(user_avg_pills_per_dose))
                    u = max(min_eff, min(max_eff, u))
                    amount = u
                source = "researched"
                return {
                    "amount_to_consume": amount,
                    "source": source,
                    "parsed_from_label": parsed_from_label,
                    "researched_used": researched_used,
                    "product_type_hint": product_type_hint,
                }

    if user_avg_pills_per_dose is not None:
        u = int(round(user_avg_pills_per_dose))
        u = max(min_eff, min(max_eff, u))
        source = "parsed_and_researched" if (parsed and researched) else "parsed" if parsed else "researched" if researched else "default"
        return {
            "amount_to_consume": u,
            "source": source,
            "parsed_from_label": parsed_from_label,
            "researched_used": researched_used,
            "product_type_hint": product_type_hint,
        }

    if researched and "typical_per_dose" in researched:
        t = min(max(0, int(researched["typical_per_dose"])), DEFAULT_MAX_PILLS)
        t = max(min_eff, min(max_eff, t))
        source = "parsed_and_researched" if (parsed and researched) else "researched"
        return {
            "amount_to_consume": t,
            "source": source,
            "parsed_from_label": parsed_from_label,
            "researched_used": researched_used,
            "product_type_hint": product_type_hint,
        }

    amount = (min_eff + max_eff) // 2
    source = "parsed_and_researched" if (parsed and researched) else "parsed" if parsed else "researched" if researched else "default"
    return {
        "amount_to_consume": amount,
        "source": source,
        "parsed_from_label": parsed_from_label,
        "researched_used": researched_used,
        "product_type_hint": product_type_hint,
    }


def user_avg_pills_for_vitamin(intake_records: list, vitamin_type: str) -> Optional[float]:
    """
    From intake records (list of dicts with vitaminType, numberOfPills),
    return average numberOfPills per intake event for the given vitamin_type (aggregate only).
    """
    if not intake_records or not vitamin_type:
        return None
    key = vitamin_type.strip().title()
    values = []
    for r in intake_records:
        vt = (r.get("vitaminType") or "").strip().title()
        if vt != key:
            continue
        np = r.get("numberOfPills")
        if np is not None:
            try:
                values.append(int(np))
            except (TypeError, ValueError):
                pass
    if not values:
        return None
    return sum(values) / len(values)
