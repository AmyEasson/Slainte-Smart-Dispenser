"""
NLP pipeline (regex + rule-based NER) to extract dosage constraints from
supplement/vitamin description or instructions text.
Supports word numbers (one, two, three...), directions-first parsing, and evidence snippets.
Output: min/max per dose or per day for use by the recommendation service.
"""
import re
from typing import Optional

# Cap for "extremely large" parsed values; downstream uses DEFAULT_MAX_PILLS
PARSE_CAP = 10

# Word to digit for dosage-like contexts only
WORD_TO_NUM = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
}

# Keywords that suggest a sentence contains dosage directions (for scoring)
DIRECTION_KEYWORDS = [
    "take", "dose", "daily", "tablet", "tablets", "pill", "pills",
    "per day", "a day", "throughout", "directions", "do not exceed",
    "max", "maximum", "once", "twice", "cap", "capsule", "softgel",
]
# Unit words for dose patterns (tablet, pill, cap, capsule, softgel)
_UNIT = r"(?:tablet|pill|cap|capsule|softgel)s?"


def _normalize_word_numbers(text: str) -> str:
    """
    Replace word numbers with digits only in dosage-like contexts
    (e.g. after 'take', before 'tablet'/'pill'/'per day'/'throughout the day').
    """
    if not text or not text.strip():
        return text
    work = text
    # Pattern: word number in context (take X, X tablets, X per day, X throughout the day, X a day)
    for word, num in WORD_TO_NUM.items():
        # "take three" / "take one"
        work = re.sub(
            re.compile(rf"\btake\s+{word}\b", re.I),
            f"take {num}",
            work,
        )
        # "three tablets" / "two pills" / "one softgel"
        work = re.sub(
            re.compile(rf"\b{word}\s+((?:tablet|pill|cap|capsule|softgel)s?)", re.I),
            lambda m: f"{num} {m.group(1)}",
            work,
        )
        # "three per day" / "two a day"
        work = re.sub(
            re.compile(rf"\b{word}\s+(?:per\s+day|a\s+day)\b", re.I),
            f"{num} per day",
            work,
        )
        # "three throughout the day" / "take two throughout the day"
        work = re.sub(
            re.compile(rf"\b{word}\s+throughout\s+the\s+day\b", re.I),
            f"{num} throughout the day",
            work,
        )
        work = re.sub(
            re.compile(rf"take\s+{word}\s+throughout", re.I),
            f"take {num} throughout",
            work,
        )
    return work


def _score_sentence(sentence: str) -> int:
    """Score a sentence by dosage-related keywords; higher = more likely to contain directions."""
    lower = sentence.lower()
    return sum(1 for k in DIRECTION_KEYWORDS if k in lower)


def _split_sentences(text: str) -> list[str]:
    """Split text into sentences (by . ! ? and newlines), strip empty."""
    if not text:
        return []
    # Split on sentence boundaries but keep structure
    chunks = re.split(r"(?<=[.!?])\s+|\n+", text)
    return [c.strip() for c in chunks if c.strip()]


def _compile_patterns() -> list[tuple[re.Pattern, str]]:
    """Compile regex patterns and return (pattern, kind) for extraction. All use \\d+ (after normalization)."""
    u = _UNIT
    patterns = [
        # Throughout the day: "take 3 throughout the day", "3 tablets throughout the day"
        (re.compile(rf"(?:take\s+)?(\d+)\s*{u}\s*throughout\s*the\s*day", re.I), "single_per_day"),
        (re.compile(r"(\d+)\s*throughout\s*the\s*day", re.I), "single_per_day"),
        # Range per dose
        (re.compile(rf"(\d+)\s*[-–to]\s*(\d+)\s*{u}", re.I), "range_per_dose"),
        (re.compile(r"take\s+(\d+)\s*[-–to]\s*(\d+)\s*(?:tablet|pill|cap|capsule|softgel)", re.I), "range_per_dose"),
        # Single per dose: "take 1 softgel", "take 2 tablets"
        (re.compile(r"take\s+(\d+)\s*(?:tablet|pill|cap|capsule|softgel)", re.I), "single_per_dose"),
        (re.compile(rf"(\d+)\s*{u}\s*(?:daily|once|twice|a day)", re.I), "single_per_dose"),
        # Per day: "3 times per day", "2 tablets per day"
        (re.compile(r"(\d+)\s*times\s*per\s*day", re.I), "single_per_day"),
        (re.compile(r"(\d+)\s*times\s*a\s*day", re.I), "single_per_day"),
        (re.compile(r"(\d+)\s*(?:x|×)\s*per\s*day", re.I), "single_per_day"),
        (re.compile(rf"(\d+)\s*{u}\s*per\s*day", re.I), "single_per_day"),
        (re.compile(rf"(\d+)\s*{u}\s*a\s*day", re.I), "single_per_day"),
        (re.compile(r"(\d+)\s*per\s*day", re.I), "single_per_day"),
        # Max per day
        (re.compile(r"(?:do not exceed|max(?:imum)?)\s*(\d+)\s*(?:tablet|pill|cap|capsule|softgel)?s?", re.I), "max_per_day"),
        (re.compile(r"(\d+)\s*(?:mg|g|IU)\s*per\s*day", re.I), "numeric_per_day"),
    ]
    return patterns


def _extract_dosage_entities(text: str) -> list[tuple[int, int, str, str]]:
    """
    Rule-based extraction: find (min_val, max_val, kind, snippet).
    Returns list of (min_val, max_val, kind, matched_text) for each match.
    """
    results = []
    patterns = _compile_patterns()
    for pattern, kind in patterns:
        for m in pattern.finditer(text):
            g = m.groups()
            snippet = m.group(0).strip()[:80]
            if kind == "range_per_dose" and len(g) >= 2:
                lo, hi = int(g[0]), int(g[1])
                results.append((min(lo, hi), max(lo, hi), "per_dose", snippet))
            elif kind == "single_per_dose" and len(g) >= 1:
                n = int(g[0])
                results.append((n, n, "per_dose", snippet))
            elif kind == "single_per_day" and len(g) >= 1:
                n = int(g[0])
                results.append((n, n, "per_day", snippet))
            elif kind == "max_per_day" and len(g) >= 1:
                n = int(g[0])
                results.append((0, n, "per_day", snippet))
            elif kind == "numeric_per_day" and len(g) >= 1:
                n = int(g[0])
                if n <= 99:
                    results.append((0, min(n, PARSE_CAP), "per_day", snippet))
    return results


def _merge_entities(entity_lists: list[list[tuple[int, int, str, str]]]) -> tuple[list[tuple[int, int, str]], list[str]]:
    """
    Merge multiple entity lists: take strictest max, combine evidence snippets.
    Returns (entities without snippet, evidence list).
    """
    merged: list[tuple[int, int, str]] = []
    evidence: list[str] = []
    for elist in entity_lists:
        for lo, hi, kind, snippet in elist:
            merged.append((lo, hi, kind))
            if snippet and snippet not in evidence:
                evidence.append(snippet)
    return merged, evidence


def parse_dosage_from_text(description: str) -> Optional[dict]:
    """
    Parse supplement description/instructions and return structured dosage constraints.
    Uses directions-first parsing and word-number normalization.

    Returns dict with keys: min_per_dose, max_per_dose, max_per_day, unit, evidence
    or None if no usable constraint found.
    """
    if not description or not description.strip():
        return None
    text = description.strip()
    normalized = _normalize_word_numbers(text)

    # Directions-first: score sentences, process high-scoring first then rest
    sentences = _split_sentences(normalized)
    scored = [(_score_sentence(s), s) for s in sentences]
    scored.sort(key=lambda x: -x[0])  # high score first

    high = [s for _, s in scored if _score_sentence(s) > 0]
    low = [s for _, s in scored if _score_sentence(s) == 0]

    entity_lists = []
    for s in high:
        entity_lists.append(_extract_dosage_entities(s))
    for s in low:
        entity_lists.append(_extract_dosage_entities(s))

    # Also run on full normalized text to catch cross-sentence patterns
    entity_lists.append(_extract_dosage_entities(normalized))

    merged, evidence = _merge_entities(entity_lists)
    if not merged:
        return None

    min_per_dose: Optional[int] = None
    max_per_dose: Optional[int] = None
    max_per_day: Optional[int] = None

    for lo, hi, kind in merged:
        lo = min(lo, PARSE_CAP)
        hi = min(hi, PARSE_CAP)
        if kind == "per_dose":
            if min_per_dose is None:
                min_per_dose = lo
                max_per_dose = hi
            else:
                min_per_dose = min(min_per_dose, lo)
                max_per_dose = max(max_per_dose, hi) if max_per_dose is not None else hi
        else:
            if max_per_day is None:
                max_per_day = hi
            else:
                max_per_day = min(max_per_day, hi)

    if max_per_day is not None and min_per_dose is None and max_per_dose is None:
        min_per_dose = 0
        max_per_dose = max_per_day

    if min_per_dose is None and max_per_dose is None:
        return None

    evidence_str = "; ".join(evidence[:3]) if evidence else None
    return {
        "min_per_dose": min_per_dose if min_per_dose is not None else 0,
        "max_per_dose": max_per_dose if max_per_dose is not None else PARSE_CAP,
        "max_per_day": max_per_day,
        "unit": "tablets",
        "evidence": evidence_str,
    }
