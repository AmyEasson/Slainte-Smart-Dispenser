#ifndef DISPENSER_H
#define DISPENSER_H

void setupHardwarePins();
void runDispenseCycle();

#endif
